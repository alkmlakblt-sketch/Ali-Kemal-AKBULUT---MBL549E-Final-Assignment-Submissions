Methodology:  
1-Data were scraped from Wikipedia.
2- Modernist architecture was selected for data scraping, specifically the architect "Frank Lloyd" was selected.
3- Frank Lloyd's buildings were scraped.
4- The dataset was filtered to include only residential buildings located in the United States.
5- Buildings were grouped by state to examine their numerical distribution.
6- Frequency counts were calculated for each state.
7- The results were visualized using a bar chart to illustrate the distribution of Frank Lloyd Wright’s residential works across U.S. states.

Data Fields: 
building_name
state
city
building_type
source_url → Wikipedia page

Rate Limit Approach: Since the data is scraped from a single page, it is not necessary.